## Contributors
This is the official list of people who can contribute (and typically have contributed) code to the QRCodeReaderViewController repository.

Names should be added to this file like so:
``` * [Firstname Lastname|Nickname](github_page_url)```

Please keep the list sorted.

### Lead developer

 * [Yannick Loriot](https://github.com/YannickL)

### People and companies, who have contributed

 * [Akira Matsuda](https://github.com/0x0c)
 * [Andrea Mazzini](https://github.com/andreamazz)
 * [Jan](https://github.com/jaltek)
 * [Nick Brook](https://github.com/nrbrook)
